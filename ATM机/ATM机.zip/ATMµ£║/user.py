'''
用户：User
    属性：名字、手机号、身份证号、卡
    行为：
'''
class User:

    def __init__(self,name,phone,id,card):
        self.name=name
        self.phone=phone
        self.id=id
        self.card=card